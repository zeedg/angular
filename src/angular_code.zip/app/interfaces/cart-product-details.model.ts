interface CartProductDetails {
    product_id: number,
    unit_id: number,
    product_quantity: number,
    product_bundle: number
}
