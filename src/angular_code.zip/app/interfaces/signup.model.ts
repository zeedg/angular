interface Signup {
    fname: string;
    lname: string;
    email: string;
    password: string;
    cpassword: string;
}
