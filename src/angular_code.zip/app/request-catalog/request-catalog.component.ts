import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-catalog',
  templateUrl: './request-catalog.component.html',
  styleUrls: ['./request-catalog.component.css']
})
export class RequestCatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
