import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-inquiry',
  templateUrl: './general-inquiry.component.html',
  styleUrls: ['./general-inquiry.component.css']
})
export class GeneralInquiryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
